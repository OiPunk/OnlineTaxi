self.__precacheManifest = [
  {
    "revision": "735ab4f94fbcd57074377afca324c813",
    "url": "/router/robots.txt"
  },
  {
    "revision": "5a4ae201ba5845898ea9",
    "url": "/router/js/chunk-vendors.e63eea42.js"
  },
  {
    "revision": "965d0cde4f9142526c1e",
    "url": "/router/js/app.104a3355.js"
  },
  {
    "revision": "b2769256b753f771df9c15a8718929d9",
    "url": "/router/index.html"
  },
  {
    "revision": "92c32b37a1fbda8293df8c45e3abb06f",
    "url": "/router/img/iconfont.92c32b37.svg"
  },
  {
    "revision": "965d0cde4f9142526c1e",
    "url": "/router/css/app.04d39307.css"
  }
];