self.__precacheManifest = [
  {
    "revision": "047d7b2ec3dc1755dd58",
    "url": "/css/app.8279e03a.css"
  },
  {
    "revision": "047d7b2ec3dc1755dd58",
    "url": "/js/app.b5149fc7.js"
  },
  {
    "revision": "5a4ae201ba5845898ea9",
    "url": "/js/chunk-vendors.e63eea42.js"
  },
  {
    "revision": "e142b3f081fefbcffcd4f75c496f2dbd",
    "url": "/img/iconfont.e142b3f0.svg"
  },
  {
    "revision": "61ad9e5ed3c4be112bb7a19cf9f5967a",
    "url": "/index.html"
  },
  {
    "revision": "b6216d61c03e6ce0c9aea6ca7808f7ca",
    "url": "/robots.txt"
  }
];